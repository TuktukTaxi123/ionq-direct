# ionq-direct
This package allows you to input a pennylane quantum circuit and output a file ready for direct ionq job submission.
